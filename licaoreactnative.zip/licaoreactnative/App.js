import * as React from 'react';
import { Text, View, StyleSheet, TextInput, Button} from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
     <AssetExample />
      <Text>USUÁRIO:</Text>
      <TextInput style={styles.caixatxt}  placeholder = "Nome" 
       style1={styles.textInput_Style}
       underlineColorAndroid='transparent'>
      </TextInput>
      <Text> SENHA: </Text>
      <TextInput style={styles.caixatxt} placeholder = "*******" 
       style1={styles.textInput_Style}
       underlineColorAndroid='transparent'/>

      <Button style={styles.cadastrar}
       title="LOGAR"
       color="#8B0000"
       
      />
      
      <View style={styles.espaco}></View>

      <Button
      title="CADASTRAR"
      color="#06FF27"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#cccccc',
    padding: 8,
  },

caixatxt: {
height:30,
margin:12,
padding: 10,
backgroundColor: '#ffffff',
},

 cadastrar:{
  widht:'5px',
 },

 espaco: {
   height: 20
 }
});
